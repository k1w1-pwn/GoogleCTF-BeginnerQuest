#!/bin/bash

echo "=== MAKING CLEAN BUILD ==="
rm -f *.o chal

echo "=== BUILDING DEBUG VERSION FOR TESTING ==="
for src in *.cc; do
  g++ "$src" -c -o "${src%.cc}.o" -fsanitize=undefined
done
g++ *.o -o chal -fsanitize=undefined

for input in *.i; do
  ./chal < "$input" | grep -av "^#" > "${input%.i}.o"
done

b2sum -c B2SUM --quiet
if [[ "$?" -ne 0 ]]; then
  echo "Error: Outputs do not match references."
  exit 1
fi

echo "=== BUILDING RELEASE VERSION ==="
for src in *.cc; do
  g++ -O2 "$src" -c -o "${src%.cc}.o"
done
g++ -O2 *.o -o chal

echo "=== REMOVING TEMPORARY FILES ==="
rm -f *.o

echo "=== DONE: BINARY BUILT AT chal ==="
