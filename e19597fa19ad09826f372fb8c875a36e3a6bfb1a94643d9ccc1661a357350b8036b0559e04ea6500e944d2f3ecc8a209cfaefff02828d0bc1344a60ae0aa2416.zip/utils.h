#pragma once

size_t ReadCmd(char *buffer, size_t max_len);
size_t ReadAll(char *buffer, size_t max_len);
