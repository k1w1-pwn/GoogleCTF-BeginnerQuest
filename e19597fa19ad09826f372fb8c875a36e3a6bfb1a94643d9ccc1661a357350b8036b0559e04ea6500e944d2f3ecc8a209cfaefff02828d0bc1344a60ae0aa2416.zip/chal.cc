#include <cassert>
#include <cctype>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#include "utils.h"

constexpr size_t kBufferSize = 2000;

const char* kHelloMsgPath = "hello_message";
const char* kGoodbyeMsgPath = "goodbye_message";

int main(int argc, char* argv[]) {
  {
    FILE* f = fopen(kHelloMsgPath, "r");
    assert(f != nullptr);
    int c{};
    while ((c = fgetc(f)) != EOF) {
      putchar(c);
      fflush(nullptr);
    }
    fclose(f);
  }

  char* buffer = new char[kBufferSize];
  ReadCmd(buffer, kBufferSize);

  if (strncmp(buffer, "encrypt", sizeof(buffer)) == 0) {
    size_t length = ReadAll(buffer, kBufferSize);

    for (size_t i = 0; i < length; ++i) {
      buffer[i] = static_cast<char>(static_cast<uint8_t>(buffer[i]) + 30);
    }

    for (size_t i = 0; i < length; ++i) {
      putchar(buffer[i]);
    }
    putchar('\n');
  } else if (strncmp(buffer, "decrypt", sizeof(buffer)) == 0) {
    size_t length = ReadAll(buffer, kBufferSize);

    for (size_t i = 0; i < length; ++i) {
      buffer[i] = static_cast<char>(static_cast<uint8_t>(buffer[i]) + 226);
    }

    for (size_t i = 0; i < length; ++i) {
      putchar(buffer[i]);
    }
    putchar('\n');
  } else {
    puts("INCORRECT COMMAND!");
  }

  delete[] buffer;

  {
    FILE* f = fopen(kGoodbyeMsgPath, "r");
    assert(f != nullptr);
    int c{};
    while ((c = fgetc(f)) != EOF) {
      putchar(c);
      fflush(nullptr);
    }
    fclose(f);
  }
}
