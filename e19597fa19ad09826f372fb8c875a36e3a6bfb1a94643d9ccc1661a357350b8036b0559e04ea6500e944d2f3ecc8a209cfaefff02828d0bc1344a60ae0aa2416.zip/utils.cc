#include <cstdio>

size_t ReadCmd(char *buffer, size_t max_len) {
  size_t len = 0;
  int c{};
  while ((c = fgetc(stdin)) != EOF) {
    if (c == '\n') break;
    buffer[len++] = c;
    if (len + 1 >= max_len) break;
  }
  buffer[len] = '\0';
  return len;
}

size_t ReadAll(char *buffer, size_t max_len) {
  size_t len = 0;
  int c{};
  while ((c = fgetc(stdin)) != EOF) {
    buffer[len++] = c;
    if (len > 3 && buffer[len - 3] == 'E' && buffer[len - 2] == 'O' &&
        buffer[len - 1] == 'F')
      break;
    if (len + 1 >= max_len) break;
  }
  buffer[len] = '\0';
  return len;
}
